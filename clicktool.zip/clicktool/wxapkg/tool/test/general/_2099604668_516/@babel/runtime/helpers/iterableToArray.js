function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && Symbol.iterator in Object(r)) return Array.from(r);
}

module.exports = _iterableToArray;