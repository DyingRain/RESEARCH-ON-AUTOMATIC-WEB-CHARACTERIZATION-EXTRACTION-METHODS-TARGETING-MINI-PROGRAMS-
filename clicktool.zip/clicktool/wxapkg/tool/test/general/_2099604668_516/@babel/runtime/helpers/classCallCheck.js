function _classCallCheck(a, l) {
    if (!(a instanceof l)) throw new TypeError("Cannot call a class as a function");
}

module.exports = _classCallCheck;