# 禁止点击的区域
blocked_areas = [
    (0, 0, 1080, 50),
    (760,80, 1064, 197)
]
clicked_elements=set()